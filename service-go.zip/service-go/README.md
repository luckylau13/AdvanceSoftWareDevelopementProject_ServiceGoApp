# service-go
A web based application that helps in household works.
