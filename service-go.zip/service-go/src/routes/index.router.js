import { Router } from "express";
import { index } from "../controllers/index.controller";

export const indexRouter = Router();

indexRouter
  .route("/")
  .get(index)
  .post();
