import { Router } from "express";
import { logTheUserController } from "../controllers/user.controller";

export const userRouter = Router();

userRouter
  .route("/")
  .get(logTheUserController)
  .post();

userRouter
  .route("/:id")
  .get()
  .put()
  .delete();
