import { Router } from "express";

import { userRouter } from "./user.router";
import { indexRouter } from "./index.router";

import { errorHandler } from "../services/errorHandler";

export const router = Router();

// Index route
router.use("/", indexRouter);

router.use("/user", userRouter);
// Use other routers here

// At last > for error handling
router.use(errorHandler);
