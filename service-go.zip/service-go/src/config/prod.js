require("dotenv").config();
export const config = {
  expireTime: "",
  secrets: {
    JWT_SECRET: ""
  },
  db: {
    url: `${process.env.MONGO_URL}`
  }
};
