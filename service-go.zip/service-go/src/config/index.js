import merge from "lodash.merge";

process.env.NODE_ENV = process.env.NODE_ENV || "development";

const env = process.env.NODE_ENV;

const actualConfig = {
  port: 3000,
  secrets: {},
  db: {
    url: "mongodb://localhost/servicego"
  }
};

let envBasedConfig = {};

switch (env) {
  case "development":
  case "dev":
    envBasedConfig = require("./dev").config;
    break;

  case "test":
  case "testing":
    envBasedConfig = require("./testing").config;
    break;

  case "prod":
  case "production":
    envBasedConfig = require("./prod").config;

  default:
    envBasedConfig = require("./dev").config;
}

export default merge(actualConfig, envBasedConfig);
