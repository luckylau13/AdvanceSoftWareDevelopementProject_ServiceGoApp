export const config = {
  expireTime: "",
  secrets: {
    JWT_SECRET: ""
  },
  db: {
    url: ""
  }
};
