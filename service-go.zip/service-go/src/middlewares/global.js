import { urlencoded, json } from "body-parser";
import morgan from "morgan";

const globalMiddleware = app => {
  // Morgan for logging only in dev env
  app.use(morgan("dev"));
  // Body parser
  app.use(urlencoded({ extended: true }));
  app.use(json());
};

export default globalMiddleware;
