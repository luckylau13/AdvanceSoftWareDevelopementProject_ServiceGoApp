import { User } from "../models/user.model";

// Write user controllers here
export const logTheUserController = (req, res, next) => {
  res.render("home");
};
