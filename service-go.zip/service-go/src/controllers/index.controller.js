export const index = (req, res, next) => {
  // Enable location
  // get data from user's location
  // pass user's data in gClient sso that we get the json blob
  // Show maps in home page
  // Show their default location
  res.render("homepage");
};
