import express from "express";
import exphbs from "express-handlebars";
import { join } from "path";
import sassMiddleware from "node-sass-middleware";

import { globalMiddleware } from "./middlewares";
import { connect } from "./db";
import { router } from "./routes";

// app is top level application declared from express
const app = express();

// Setup all middlwares
globalMiddleware(app);
// Connect to the database
connect();

// using sass instead of css
app.use(
  sassMiddleware({
    src: __dirname + "/sass",
    dest: __dirname + "/public",
    debug: true,
    outputStyle: "compressed"
  })
);
console.log(join(__dirname, "public"));

// Set view engine
app.engine("hbs", exphbs({ defaultLayout: "main", extname: ".hbs" }));
app.set("views", join(__dirname, "views"));
app.set("view engine", "hbs");

//public
app.use(express.static(join(__dirname, "public")));

// Routing
app.use("/", router);

// catch all
app.all("*", (req, res) => {
  res.json({ success: true });
});

export default app;
